LUCKY 777 — INSTALACIÓN EN IPHONE

1. Sube el contenido de esta carpeta a un hosting HTTPS (por ejemplo, GitHub Pages).
2. Abre la dirección HTTPS publicada en Safari en tu iPhone.
3. Toca Compartir (cuadrado con flecha hacia arriba).
4. Elige "Añadir a pantalla de inicio" y toca "Añadir".
5. Abre Lucky 777 desde el nuevo icono.

NOTA: Para instalar como app web, debe estar publicada en una dirección HTTPS. El archivo HTML también se puede abrir para probarlo, pero la instalación PWA y el modo sin conexión requieren hosting HTTPS.
El sonido se activa al tocar GIRAR por primera vez debido a las restricciones de audio de iPhone.
Juego solo con créditos virtuales, sin dinero real.
